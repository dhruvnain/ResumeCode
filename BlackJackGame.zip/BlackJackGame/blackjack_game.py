from player import Player
from dealer import Dealer


class BlackjackGame:
    def __init__(self, player_names):
        self.player_names = player_names
        self.dealer = Dealer()
        self.player_list = []
        for i in range(0,len(self.player_names)):
            player = Player(player_names[i] , self.dealer)
            self.player_list.append(player)


    def play_rounds(self, num_rounds=1):
        """
        >>> import random; random.seed(1)
        >>> game = BlackjackGame(["Lawrence","Melissa"])
        >>> print(game.play_rounds(2))
        Round 1
        Dealer: [10, 9] 0/0/0
        Lawrence: [10, 6, 3] 0/1/0
        Melissa: [8, 8] 0/0/1
        Round 2
        Dealer: [10, 10] 0/0/0
        Lawrence: [10, 3] 0/1/1
        Melissa: [9, 10] 0/0/2
        """
        j = 0
        lst = []
        while j < num_rounds:
            for element in self.player_list:
                element.hand = []
            self.dealer.hand = []
            self.dealer.shuffle_deck()

            k = 0
            while k < 2:
                for element in self.player_list:
                    self.dealer.signal_hit(element)
                self.dealer.signal_hit(self.dealer)
                k+=1

            for element in self.player_list:
                element.play_round()
            self.dealer.play_round()

            for element in self.player_list:
                if element.card_sum > 21:
                    element.record_loss()
                else:
                    if element.card_sum > self.dealer.card_sum:
                        element.record_win()
                    if element.card_sum < self.dealer.card_sum and self.dealer.card_sum <= 21 :
                        element.record_loss()
                    elif element.card_sum == self.dealer.card_sum:
                        element.record_tie()
                    elif self.dealer.card_sum>21 and element.card_sum<=21 :
                        element.record_win()
            rounds = "Round" + " " + str(j+1)
            lst.append(rounds)
            lst.append(str(self.dealer))

            for element in self.player_list:
                lst.append(str(element))
            j+=1

        result = ""
        for element in lst:
            result = result+element+"\n"
        return "".join([s for s in result.strip().splitlines(True) if s.strip()])

    def reset_game(self):
        """
        >>> game = BlackjackGame(["Lawrence", "Melissa"])
        >>> _ = game.play_rounds()
        >>> game.reset_game()
        >>> game.player_list[0]
        Lawrence: [] 0/0/0
        >>> game.player_list[1]
        Melissa: [] 0/0/0
        """
        for element in self.player_list:
            element.hand = []
            element.win = 0
            element.tie = 0
            element.loss = 0


        



if __name__ == "__main__":
    import doctest
    doctest.testmod()
